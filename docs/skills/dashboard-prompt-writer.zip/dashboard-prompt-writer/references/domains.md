# Starter sets by kind of data

Common practice, not a standard. Use only what the data's columns support, and use the organisation's own KPI definitions where they exist.
Each set lists: likely dashboard type, KPI cards, charts, drivers to test, what-if levers.

## Sales
Type: executive or analytical.
Cards: revenue vs target or prior year, gross margin %, quota attainment, pipeline coverage (pipeline ÷ remaining target), win rate, average deal size.
Charts: monthly revenue trend with target line; sorted bar of reps, branches or products vs target; waterfall from last year's revenue to this year's (price, volume, mix, new, lost); Pareto of customers by revenue.
Drivers: price, volume, product mix, region, new vs returning customers, sales cycle length.
What-if: price change %, conversion rate, extra reps, discount level.

## Finance
Type: executive.
Cards: actual vs budget and prior year (AC vs BU vs PY), variance £ and %, full-year forecast, gross and operating margin, cash and runway, days to collect payment (DSO).
Charts: P&L lines as actual vs budget with variance bars; waterfall from budget to actual; monthly trend actual vs budget vs forecast; cost centres ranked by variance.
Drivers: the largest variance lines, one-off vs recurring, volume vs rate.
What-if: revenue growth %, cost cut %, hiring freeze months, FX rate; sensitivity grid of two levers on profit.

## Projects and programmes (PMO)
Type: operational.
Cards: projects on track / at risk / late (RAG), budget spent vs planned, schedule variance, milestones due in 30 days, open risks and issues.
Charts: milestone Gantt or timeline; planned vs actual progress (burn-up); risk matrix (likelihood × impact); projects ranked by slip or overspend.
Drivers: dependencies, resource gaps, scope changes, supplier delays.
What-if: add people, move a milestone, cut scope.

## Jira and agile teams
Type: operational or analytical.
Cards: committed vs completed story points, open issues vs last sprint, overdue items, cycle time (start to done), work in progress.
Charts: sprint burndown; velocity per sprint with average line; cumulative flow (items by status over time); cycle time scatter with 85th percentile line; created vs resolved per week; assignees ranked by open work.
Drivers: issue type, priority, component, blocked time, reopened items.
What-if: extra capacity per sprint, work-in-progress limit, drop low-priority items.

## Customer service and support
Type: operational.
Cards: open tickets and backlog age, first response vs target, resolution time, first-contact resolution %, SLA met %, satisfaction (CSAT).
Charts: volume and backlog per week; categories as a Pareto; heat map of volume by weekday and hour; teams ranked by SLA breaches.
Drivers: channel, category, time of day, repeat contacts, agent tenure.
What-if: extra agents, self-service deflection %, faster first response.

## People and HR
Type: executive.
Cards: headcount vs plan, attrition vs last year, open roles, time to hire, absence rate.
Charts: joiners and leavers per month; teams ranked by attrition; tenure histogram; cohort grid of new-joiner retention.
Drivers: tenure band, manager, grade, location, pay band.
What-if: retention programme effect, hiring rate, absence reduction.

## Marketing
Type: analytical.
Cards: leads vs target, cost per lead, conversion rate, cost to win a customer (CAC), return on ad spend (ROAS).
Charts: funnel from visit to customer; channels ranked by cost per lead; spend vs return scatter with quadrants; monthly trend by channel.
Drivers: channel, campaign, audience, creative, landing page.
What-if: budget shift between channels, conversion uplift.

## Operations and supply chain
Type: operational.
Cards: on time in full (OTIF), inventory turns, stock-outs, defect rate, equipment effectiveness (OEE).
Charts: Pareto of defects or delay reasons; supplier scatter of cost vs on-time rate; weekly trend vs target; sites ranked by OTIF.
Drivers: supplier, site, shift, product, lead time.
What-if: safety stock level, supplier switch, lead time reduction.

## Surveys
Type: analytical.
Cards: responses, average score, % would recommend, top complaint.
Charts: score by group as sorted bar; question-by-group heat map; trend by wave if dates exist.
Drivers: which questions move the headline score most.
What-if: lift the lowest group to the average.
