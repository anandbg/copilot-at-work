# Dashboard rules the prompts must carry

Based on Microsoft Learn Power BI guidance, Tableau's published dashboard best practice, the IBCS business-chart standard, and common practice from public Copilot dashboard demos. Lines marked (practice) are common practice without a single primary source.

## 1. Pick the dashboard type first

| Type | For | What it needs |
|---|---|---|
| Executive | Leaders checking performance | 3 to 5 KPI cards, one trend, one variance chart. Summary level only. |
| Operational | Teams running the day or week | Status colours, exceptions list (what is late, breached, over limit), current period only. |
| Analytical | Analysts finding causes | Filters, drill-down, driver breakdown, scatter or decomposition. |
| Scenario planning | Deciding between options | Input sliders top or left, results beside them, base vs scenario, assumptions box. (practice) |

Keep each dashboard to 2 or 3 main views and one screen with no scrolling. If the story needs more, ask for a second page.

## 2. Audience and decision
Name who reads it and what they must decide.
"For the finance director's Q3 review: should we keep funding the York store?" beats "a sales dashboard".

## 3. KPI cards
- 3 to 5 cards, top left, larger than everything else.
- Each card: actual, comparison (target, budget, prior year or prior period), variance as value and %, a small trend line (sparkline), and a status mark. (practice)
- Use a bullet chart or progress bar for performance against a goal.
- Business notation, if the user's world uses it: AC actual, PY previous year, PL plan, BU budget, FC forecast (IBCS).

## 4. Variance colour follows business impact
Green is good, red is bad, grey is neutral, whatever the sign.
A rise in costs, complaints or churn is red. A fall in costs is green.
Ask for a colour-blind safe pair (for example blue and orange) where the audience is wide.

## 5. Choose the chart by the question

| Question | Chart |
|---|---|
| How is it moving over time? | Line, one consistent time grain |
| Why is it happening? | Breakdown by the candidate drivers: heat map of measure by item × driver, or scatter of measure against driver, then the drivers follow-up |
| Which of two or three options is better? | Side-by-side bars or a small table of the options on the same measures |
| Who is biggest or smallest? | Sorted bar |
| How did we get from A to B? | Waterfall (bridge) |
| Which few causes drive most of it? | Pareto: sorted bar plus cumulative % line |
| How do two measures relate? | Scatter, with average lines splitting it into four quadrants |
| How is it spread? | Histogram |
| What is it made of? | Stacked bar or treemap; pie only below 8 slices |
| Where? | Map: bubbles for totals, shaded areas for rates |
| Item by item across two groupings? | Heat map |
| Same chart for each group? | Small multiples on a shared scale |
| How long, and when? | Gantt or timeline |
| Did customers stay? | Cohort grid (practice) |
| Where do people drop out? | Funnel (practice) |

Never 3D. Avoid gauges except a single status against a goal.

## 6. Interactivity
- Filters (slicers) with plain names for the main groupings: period, region, team, product.
- Cross-filtering: clicking one chart filters the others.
- Drill-down: click a bar to see the level below (region, then store).
- Detail on click: the selected item's figures plus a one-sentence takeaway.
- Tooltips on hover with the exact value and comparison.
- A measure switch where useful, for example Revenue / Margin / Orders on one toggle.
- A subtitle telling the reader what they can click.

## 7. Drivers
Ask what is driving the main measure. Name the candidate columns so Copilot tests them.
Ask for the chart that proves the strongest driver.
If the comparison rests on fewer than about 10 groups, ask Copilot to say how strong the evidence is.

## 8. Scenarios and what-if
- One or two sliders for levers the reader controls, each with a stated range and step.
- Preset buttons for Base, Upside and Downside.
- Show baseline beside scenario, never the scenario alone.
- An assumptions box listing every assumption.
- For two levers, a sensitivity grid (lever A across, lever B down, outcome in cells). (practice)
- Label every scenario visual "Scenario, not actual". (practice)
- Forecasts show a range (band), not a single line.

## 9. Analytics extras
Reference lines for target and average. Flag outliers or anomalies on trend lines. Group items into segments where a scatter shows clusters. Label each line and band.

## 10. Layout and formatting
- Most important item top left; read left to right, top to bottom.
- White space between sections, not grid lines.
- Grey for everything, one accent colour for the message. Each colour keeps one meaning across charts.
- Numbers short: 3.4M, 27.4%, at most 3 or 4 digits. Units stated.
- Titles state the takeaway ("Copy paper drives the margin gap"), not the chart type.
- Colour never carries meaning alone.

## 11. Trust
- A "data as of" line with the data's latest date.
- A small check block: rows used, a total that matches the source, missing periods flagged.
- A short glossary of how each KPI is calculated.
- Ask Copilot to list every assumption and formula behind each KPI.

## 12. How Copilot builds best
- The data should be Excel tables with clear headers, no merged cells or subtotals, and calculation set to Automatic.
- Use four parts in the main prompt: goal, context (audience and decision), source (exact tables), expectations (layout, cards, charts, filters).
- Build in layers: the base dashboard first, then one addition per follow-up prompt.
- After it builds, change one source cell and check the KPIs move. Some generated metrics have been reported as fixed values.
- PowerPoint dashboards are a snapshot. Put the data date on the slide, and ask Copilot to update it before reuse. Phones and print show a still image.
