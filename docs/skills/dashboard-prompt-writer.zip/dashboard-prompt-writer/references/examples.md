# Worked examples (fictional data)

## 1. Excel, store sales, user question given

Data seen: Fernbrook Garden Supplies Sales 2026. Tables tblSales (Monthly Sales, 300 rows), tblStores (Stores, 6 rows), tblFeedback (Customer Feedback, 6 rows).
tblSales columns: Month Start, Store, Region, Product Line, Orders, Revenue £, Gross Margin £. Jan to Oct 2026.
tblStores has Monthly Target £. There is no 2025 data, so the comparison is target, then the previous month.
User: "Which stores are falling behind, and why?"

Dashboard type: executive, because the regional manager is deciding where to act.

Paste this into Copilot in Excel:
```
Using the tblSales, tblStores and tblFeedback tables, build an interactive dashboard for the regional manager to decide which stores need help first. Top row: KPI cards for year-to-date Revenue £ vs target (Monthly Target £ for each month so far), gross margin % (Gross Margin £ ÷ Revenue £) for October vs September, October Revenue £ vs September, and the store furthest below target. Left: monthly Revenue £ from January to October 2026, with a Product Line filter. Right: stores ranked by year-to-date revenue against target as a sorted bar chart, with a line at 100%. Add a panel that answers: "Which stores are falling behind, and why?" showing Satisfaction (1-5), Waiting Time Mins and Top Complaint for the stores below target. Add filters for Region and Product Line. When I click a store, show its revenue by Product Line and its monthly trend against target, with a one-sentence takeaway. Use one highlight colour for stores below target. Add a small check block with rows used and total Revenue £.
```

Then send these one at a time:
```
What is actually driving the gap to target by Store? Test Product Line mix, Waiting Time Mins, Satisfaction (1-5) and Staff. There are only 6 stores, so say how strong the evidence is. Add a panel that explains the strongest driver, with a chart that proves it.
```
```
Add a what-if panel with two sliders for a chosen store: (1) cut Waiting Time Mins by 0 to 5 minutes, using the relationship seen across stores, (2) add 0 to 3 Staff, assuming revenue per staff member stays at that store's current level. Add Base, Upside and Downside presets. Show projected revenue against target beside the current baseline, label it "Scenario, not actual", and list every assumption in a box.
```
```
Add a small check block: rows used, total Revenue £ matching tblSales, and any missing months. Then list every assumption and formula behind each KPI card.
```

What I assumed: the reader is the regional manager; comparison is the store target, because the file has no 2025 data; Click & Collect is zero before March because it launched then, so it is not a fall.
Check after it builds: compare the year-to-date Revenue £ card with a SUM of Revenue £ in tblSales, then change one Revenue £ cell and confirm the card moves.

## 2. Jira export, chat, two questions

Data seen: issues.csv, 640 rows. Columns: Key, Summary, Issue Type, Status, Priority, Assignee, Sprint, Story Points, Created, Resolved, Component.
User: "Why are we missing sprint dates? Who is overloaded?"

Paste this into Copilot in Excel:
```
Using the issues table, build an interactive dashboard for the delivery manager to decide how to rebalance the next sprint. Top row: KPI cards for open issues vs the end of last sprint, story points done this sprint vs committed, overdue issues, and average days from Created to Resolved. Left: issues created vs resolved per week. Right: assignees ranked by open story points as a sorted bar chart. Add a panel that answers "Why are we missing sprint dates?" using Issue Type, Priority and Component, and a panel that answers "Who is overloaded?" by comparing open story points per assignee with the team average. Add filters for Sprint, Component and Priority. When I click an assignee, show their open items by status and a one-sentence takeaway.
```

Follow-ups: drivers of slipped items by Component and Issue Type; what-if slider for extra story points per sprint and moving low-priority items out.
What I assumed: "committed" means story points in the sprint at its start, which this export may not hold. If not, the card shows done points only.
