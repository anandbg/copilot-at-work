# Prompt templates

Fill every <slot> from the data and the user's questions. Drop a line if the data cannot support it.
The main prompt has four parts: goal, context, source, expectations. Each follow-up adds one thing.

## Excel (Copilot in Excel dashboard / canvas)

Main:
```
Goal: build an interactive <dashboard type> dashboard so <audience> can decide <decision>.
Source: use the <table names> tables<, joined on <key column>>. Data runs <start> to <end>.
Top row: 3 to 5 KPI cards for <measure 1> vs <comparison>, <measure 2> vs <comparison>, <measure 3> and <flag item>. Each card shows the actual, the comparison, the variance as value and %, a small trend line, and green or red by business impact (<which direction is bad>).
Main area: <chart 1 for question 1>; <chart 2 for question 2>; <chart 3 for ranking>, sorted, with a <target/average> line.
Add a panel that answers: "<user question 1>"<; and one for "<user question 2>">.
Filters for <grouping A>, <grouping B> and <period>. Clicking a chart filters the others. Clicking a <item> shows its <detail measures> and a one-sentence takeaway. Hover shows exact values.
Style: grey base with one accent colour for <what to notice>, short numbers (3.4M), titles that state the takeaway, a "data as of <latest date>" line.
```

Follow-up 1, drivers:
```
What is actually driving <main measure>? Test <driver 1>, <driver 2> and <driver 3>. Add a panel that explains the strongest driver with the chart that proves it<, and say how strong the evidence is>.
```

Follow-up 2, scenarios:
```
Add a what-if panel: a slider for <lever 1> from <min> to <max> in steps of <step><, and one for <lever 2>>. Add Base, Upside and Downside preset buttons. Show projected <outcome> beside the current baseline, label it "Scenario, not actual", and list every assumption in a box.
```

Follow-up 3, trust:
```
Add a small check block: rows used, total <main measure> matching the <source table>, and any missing <periods>. Then list every assumption and formula behind each KPI card.
```

Optional follow-ups when the data supports them:
- Variance story: "Add a waterfall from <comparison> to <actual> <main measure>, broken down by <grouping>."
- Few causes: "Add a Pareto of <category> by <measure> with a cumulative % line."
- Two measures: "Add a scatter of <measure A> against <measure B> by <item>, with average lines splitting it into quadrants, and label the quadrants."
- Forecast: "Extend the trend to <date> as a forecast with a range band, labelled as a forecast."
- Measure switch: "Add a toggle to switch the main charts between <measure A>, <measure B> and <measure C>."

## PowerPoint (Create interactive slide)

Main:
```
Create a new interactive dashboard slide after this one, using <the table or results on this slide / the attached workbook's tables>. Keep this slide unchanged.
Title it "<takeaway title>". It is for <audience> to decide <decision>.
Top row: KPI tiles for <measure 1> vs <comparison>, <measure 2>, <measure 3> and <biggest gain or risk>, each with variance and green or red by business impact.
Main area: <chart> of <items> with a <period> toggle that animates the values<, and a <target> line>.
When I click a <item>, show its <detail measures> and a one-sentence takeaway. Call out <best item>; flag <worst item> in red.
Answer on the slide: "<user question>". Add "Data as of <latest date>" in the footer.
```

Follow-ups (one per turn). Always include drivers and trust:
```
What is driving <main measure>? Test <driver 1>, <driver 2> and <driver 3>, and add the chart that proves the strongest driver to the dashboard slide<, saying how strong the evidence is>.
```
```
Add a small check block to the dashboard slide: rows used and a total that matches <source>. Then list every assumption and formula behind each KPI tile.
```
Optional:
```
Turn the <table> on this slide into an interactive <heat map / cards / timeline / scatter> on a new slide. Keep this slide unchanged. Let me click <item> to <action>, and add a toggle to show <second measure>.
```
```
Add a what-if control to the dashboard slide: a slider for <lever> from <min> to <max> that updates <outcome>, with the baseline shown and the assumption labelled "Scenario, not actual".
```

Note for the user: interactive slides are a snapshot. Before reusing the deck, ask Copilot to update them from the latest data.

## Word, or no dashboard feature
Word has no dashboard builder. Write the Excel or PowerPoint prompt and tell the user to run it there.
If they want a written brief instead: "Summarise this data as a one-page brief for <audience>: 3 headline numbers with comparisons, the main trend, the strongest driver, and one recommended action."
