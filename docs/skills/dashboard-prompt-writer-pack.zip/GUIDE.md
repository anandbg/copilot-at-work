# Dashboard prompt writer: set it up in Microsoft 365 Copilot

Give it your data and your questions. It writes the prompt you paste into Copilot in Excel or PowerPoint, which then builds an interactive dashboard.
One skill folder, `dashboard-prompt-writer`, works in every place below. It has no scripts, so it needs no code interpreter.

## Excel and PowerPoint (personal)
Source: support.microsoft.com "Custom skills in Copilot in Excel" and "Use custom skills with Copilot in PowerPoint" (undated, checked 16 Nov 2026).
1. In Excel, open the Copilot pane, select ..., then Manage plugins & skills > Custom skills > Create OneDrive folder.
2. Open that folder and copy the whole `dashboard-prompt-writer` folder into it. Keep the folder name exactly. Copilot skips a folder whose name differs from `name:` in SKILL.md.
3. Select Refresh in the Custom skills dialog.
4. Open your data, then type `@dashboard-prompt-writer` and your questions.
PowerPoint reads the same OneDrive skills folder. You can also upload `dist/dashboard-prompt-writer.zip` from its Copilot pane (personal use only).

## Copilot Chat (personal)
Source: Learn "Build skills for Copilot Chat" (ms.date 11 Nov 2026).
Agents > More agents > Upload skill > choose the zip. Attach your file and ask for a dashboard prompt.

## Agent Builder agent
Source: Learn "Add skills in Agent Builder" (ms.date 12 Nov 2026), "Build agents" (ms.date 26 Oct 2026).
1. Create an agent named Dashboard Prompt Writer.
2. Paste `AGENT-INSTRUCTIONS.txt` into Instructions (under the 8,000 character cap).
3. Add the skill: upload `dist/dashboard-prompt-writer.zip`.
4. Conversation starters: "Write a dashboard prompt for this file", "Turn my questions into an Excel dashboard prompt".
Limits: 8 skills per agent, zip up to 50 MB, scripts have no network. Users in Information Barriers tenants cannot add skills.

## Whole team
Ask an admin to publish the zip at Agents > Tools > Registry and scope it to your group (Learn "Manage plugins, skills, and MCP servers", ms.date 14 Oct 2026).

## Word
I found no Microsoft page confirming custom skills in Word. Use `PROMPT-GALLERY-FALLBACK.txt`: save it in Copilot Prompt Gallery and fill the brackets.

## Run the dashboard
- Excel: the dashboard feature is Excel canvas (MC1485411). It may still be in preview in your tenant. If Copilot cannot build it, check with your admin.
- PowerPoint: Create interactive slide (MC1461152) needs a Copilot licence. Slides stay interactive on Windows, Mac, web, iPad and Teams; phones show a still image.

## Test it
1. Open `test-data/Fernbrook Garden Supplies Sales 2026.xlsx` (fictional) and ask: `@dashboard-prompt-writer Which stores are falling behind, and why?`
   Pass if the prompt names tblSales, tblStores and tblFeedback, compares against Monthly Target £ (there is no 2025 data), and gives two follow-ups.
2. Ask for a column that does not exist: "Show it by salesperson commission". The file has no salesperson column. Pass if it says there is no such column.
3. Paste the prompt into Copilot in Excel and check one KPI card against the source.

## Change it
Edit the files in `dashboard-prompt-writer/`, then rezip:
`cd ~/work/dashboard-prompt-skill && zip -qr dist/dashboard-prompt-writer.zip dashboard-prompt-writer -x '*.DS_Store'`
