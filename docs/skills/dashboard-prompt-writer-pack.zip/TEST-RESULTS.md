# Blind tests, 16 Nov 2026

A fresh AI followed only the skill files, acting as Copilot. Not a Microsoft 365 tenant test.

## Round 2 (rebuilt skill, after deeper research)
Case 1: Fernbrook in Excel, "Which stores are falling behind, and why?" Executive dashboard; every name exists; every KPI had a comparison and the right good/bad direction. Pass.
Case 2: Zava in PowerPoint, B2B vs B2C, "just do it". Every name exists; it flagged a sentence planted in a Product cell, near-duplicate customer names, duplicate sheets, and merged cells. Pass.
Case 3: "What if we cut Garden Furniture prices 10%? Show it by salesperson." It asked one question, said there is no salesperson column, then built a scenario-planning dashboard with a sensitivity grid. Pass.

12 gaps found and fixed: word range raised to 150-280; one PowerPoint opening line; ask-only-the-question rule; dashboard type chosen by the question; new chart rows for "why" and "which option"; PowerPoint drivers and trust follow-ups; the file's own scenario names used for presets; derived ratios allowed with a stated formula; existing dashboards left untouched; PowerPoint check is a snapshot reminder; the under-10-rows rule applies to the main table; duplicate sheets used once.

## Round 1
3 cases passed; 8 gaps fixed (comparison order, defaults, data-problem line, instruction text in data treated as data).
